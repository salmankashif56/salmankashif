<p align="center">
<a href="https://bit.ly/3jLqF1P"><img title="Made in Pakistan" src="https://img.shields.io/badge/MADE%20IN-Pakistan-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://bit.ly/3jLqF1P"><img title="Made in Pakistan" src="https://img.shields.io/badge/Tool-Blurforce--Abm-green.svg"></a>
<a href="https://bit.ly/3jLqF1P"><img title="Version" src="https://img.shields.io/badge/Version-3.0-green.svg?style=flat-square"></a>
<a href="https://bit.ly/3jLqF1P"><img title="Cloning" src="https://img.shields.io/badge/Cloning%3F-yes-green.svg"></a>


## Note
<p align="center">

Don't copy my script and don't edit my script... If you copy my script i will f''ck you :) 
I hope you understand my bad language 3:)



## Script run on termux or linux 
```  
➤ pkg update && upgrade
➤ pkg install git && pkg install python2
➤ pkg install python && pkg install php
➤ pip install requests && pip install mechanize 
➤ pip2 install mechanize && pip2 install requests 
➤ pip2 install requests bs4
➤ rm -rf Blueforce--Abm
➤ git clone https://github.com/Tech-abm/Blueforce--Abm
➤ cd Blueforce--Abm
➤ python2 ab.sys
```
## Tool User And Pass
```  
➤ Username : Abm
➤ Password : Abm 
```
## Option
```  
> login with token
> login with password
> without login Ph.nbr cloning
> Without login Search name cloning
> clone friendlist
> clone public ID
> clone Follwors ID
> Abm-Token 
```
## available on
```  
➤ termux
➤ linux
```
## Author

```
Alone codder : Tech Abm
```
## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

## Follows us on social media
  
<p align="center">
<a href="https://fb.com/Techabm"><img title="Facebook" src="https://img.shields.io/badge/Facebook-red?style=for-the-badge&logo=facebook"></a>
<a href="https://www.instagram.com/Techabm"><img title="Instagram" src="https://img.shields.io/badge/INSTAGRAM-purple?style=for-the-badge&logo=instagram"></a>
<a href="https://github.com/Tech-abm"><img title="Github" src="https://img.shields.io/badge/Github-TECH--ABM-blue?style=for-the-badge&logo=github"></a>
